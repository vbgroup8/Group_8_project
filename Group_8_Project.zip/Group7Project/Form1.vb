﻿Imports System.Data.OleDb

Public Class Form1
    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")
    Private Sub btnRegisterHere_Click(sender As Object, e As EventArgs) Handles btnRegisterHere.Click
        Me.Hide()
        Account_Registration.Show()

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            myCon.Open()
            Dim mycmd As New OleDbCommand("Select * from EmployeeLogin_Account where UserName= '" & txtUserName.Text & "' And [Password] = '" & txtPassoword.Text & "'", myCon)
            Dim myread As OleDbDataReader = mycmd.ExecuteReader
            If myread.Read Then
                MessageBox.Show("Login Successfully!")
                txtUserName.Clear()
                txtPassoword.Clear()
                Me.Hide()
                Menu_List.Show()
            Else
                MessageBox.Show("Invalid UserName or Password!. Check and Try Again!")
            End If
            myread.Close()
            myCon.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
