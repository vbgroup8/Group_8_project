﻿Imports System.Data.OleDb



Public Class Employee_Registration

    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")
    Dim myDA As OleDbDataAdapter
    Dim myCB As OleDbCommandBuilder
    Dim myDS As New DataSet()
    Dim myDT As DataTable

    Private Sub Employee_Registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        myDA = New OleDbDataAdapter("SELECT * FROM Employee_List", myCon)
        myCB = New OleDbCommandBuilder(myDA)
        myDA.Fill(myDS, "Employee_List")
        myDT = myDS.Tables("Employee_List")
        EmployeeListBindingSource.DataSource = myDT
    End Sub

    Private Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        EmployeeListBindingSource.AddNew()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            EmployeeListBindingSource.EndEdit()
            myDA.Update(myDT)
            MessageBox.Show("Successfully Saved")
            txtEmployeeID.Clear()
            txtFirstName.Clear()
            txtLastName.Clear()
            txtAge.Clear()
            txtGender.Clear()
            txtJobType.Clear()
            txtPayment.Clear()
            txtReligion.Clear()
            txtRegion.Clear()
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        EmployeeListBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Menu_List.Show()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        EmployeeListBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        EmployeeListBindingSource.MoveNext()
    End Sub

    Private Sub dtpDOB_ValueChanged(sender As Object, e As EventArgs) Handles dtpDOB.ValueChanged
        Dim Today, DOB As Integer

        Today = Date.Today.Year
        DOB = dtpDOB.Value.Year

        txtAge.Text = Today - DOB

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dv As New DataView(myDT)
        dv.RowFilter = "Employee_ID = '" & txtSearch.Text & "'"
        EmployeeListBindingSource.DataSource = dv

    End Sub
End Class
