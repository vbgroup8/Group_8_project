﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Doctor_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnReviewPayment = New System.Windows.Forms.Button()
        Me.btnAssignPresc = New System.Windows.Forms.Button()
        Me.btnReviewPatient = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Lime
        Me.btnLogOut.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.Location = New System.Drawing.Point(216, 159)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(175, 41)
        Me.btnLogOut.TabIndex = 32
        Me.btnLogOut.Text = "LOG OUT"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'btnClose
        '
        Me.btnClose.BackColor = System.Drawing.Color.Red
        Me.btnClose.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(16, 159)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(175, 41)
        Me.btnClose.TabIndex = 31
        Me.btnClose.Text = "CLOSE"
        Me.btnClose.UseVisualStyleBackColor = False
        '
        'btnReviewPayment
        '
        Me.btnReviewPayment.BackColor = System.Drawing.Color.White
        Me.btnReviewPayment.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReviewPayment.Location = New System.Drawing.Point(216, 53)
        Me.btnReviewPayment.Name = "btnReviewPayment"
        Me.btnReviewPayment.Size = New System.Drawing.Size(192, 88)
        Me.btnReviewPayment.TabIndex = 30
        Me.btnReviewPayment.Text = "Review Patient Payment"
        Me.btnReviewPayment.UseVisualStyleBackColor = False
        '
        'btnAssignPresc
        '
        Me.btnAssignPresc.BackColor = System.Drawing.Color.White
        Me.btnAssignPresc.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAssignPresc.Location = New System.Drawing.Point(20, 100)
        Me.btnAssignPresc.Name = "btnAssignPresc"
        Me.btnAssignPresc.Size = New System.Drawing.Size(175, 41)
        Me.btnAssignPresc.TabIndex = 29
        Me.btnAssignPresc.Text = "Assign Prescription"
        Me.btnAssignPresc.UseVisualStyleBackColor = False
        '
        'btnReviewPatient
        '
        Me.btnReviewPatient.BackColor = System.Drawing.Color.White
        Me.btnReviewPatient.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReviewPatient.Location = New System.Drawing.Point(20, 53)
        Me.btnReviewPatient.Name = "btnReviewPatient"
        Me.btnReviewPatient.Size = New System.Drawing.Size(175, 41)
        Me.btnReviewPatient.TabIndex = 28
        Me.btnReviewPatient.Text = "Review Patient"
        Me.btnReviewPatient.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(68, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(304, 25)
        Me.Label3.TabIndex = 27
        Me.Label3.Text = "WELCOME TO UENR CLINIC"
        '
        'Doctor_Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Group7Project.My.Resources.Resources._726693cf83094cf1cb60e2a107880531
        Me.ClientSize = New System.Drawing.Size(415, 213)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnReviewPayment)
        Me.Controls.Add(Me.btnAssignPresc)
        Me.Controls.Add(Me.btnReviewPatient)
        Me.Controls.Add(Me.Label3)
        Me.Name = "Doctor_Form"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Doctor_Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnLogOut As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnReviewPayment As Button
    Friend WithEvents btnAssignPresc As Button
    Friend WithEvents btnReviewPatient As Button
    Friend WithEvents Label3 As Label
End Class
