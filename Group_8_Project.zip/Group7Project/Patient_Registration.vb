﻿Imports System.Data.OleDb

Public Class Patient_Registration


    Dim myCon As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\USER\Desktop\Group7Project\bin\Debug\UenrClinicdb.accdb")
    Dim myDA As OleDbDataAdapter
    Dim myCB As OleDbCommandBuilder
    Dim myDS As New DataSet()
    Dim myDT As DataTable

    Private Sub Patient_Registration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        myDA = New OleDbDataAdapter("SELECT * FROM Patient_List", myCon)
        myCB = New OleDbCommandBuilder(myDA)
        myDA.Fill(myDS, "Patient_List")
        myDT = myDS.Tables("Patient_List")
        PatientListBindingSource.DataSource = myDT
        txtPatientID.Focus()
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            If txtPatientID.Text = "" Or txtFirstName.Text = "" Or txtLastName.Text = "" Or DateTimePicker1.Text = "" Or txtAge.Text = "" Or txtGender.Text = "" Or txtPhone.Text = "" Or txtHomeTown.Text = "" Then
                MessageBox.Show("Please fill in all required fields.")
            Else
                PatientListBindingSource.EndEdit()
                myDA.Update(myDT)
                MessageBox.Show("Patient registration successful.")

            End If
        Catch ex As Exception
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub btnAddNew_Click(sender As Object, e As EventArgs) Handles btnAddNew.Click
        PatientListBindingSource.AddNew()
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        PatientListBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Menu_List.Show()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        PatientListBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        PatientListBindingSource.MoveNext()
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        Dim Today, DOB As Integer

        Today = Date.Today.Year
        DOB = DateTimePicker1.Value.Year

        txtAge.Text = Today - DOB

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dv As New DataView(myDT)
        dv.RowFilter = "Patient_ID = '" & txtSearch.Text & "'"
        PatientListBindingSource.DataSource = dv

    End Sub
End Class
