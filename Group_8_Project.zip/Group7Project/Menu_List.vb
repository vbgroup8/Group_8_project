﻿Public Class Menu_List
    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
        Form1.Show()
    End Sub

    Private Sub btnReceptionist_Click(sender As Object, e As EventArgs) Handles btnReceptionist.Click
        Me.Hide()
        Patient_Registration.Show()

    End Sub

    Private Sub btnNurse_Click(sender As Object, e As EventArgs) Handles btnNurse.Click
        Me.Hide()
        Nurse_Confirmation.Show()
    End Sub

    Private Sub btnDoctor_Click(sender As Object, e As EventArgs) Handles btnDoctor.Click
        Me.Hide()
        Doctor_Confirmation.Show()
    End Sub

    Private Sub btnPharmacist_Click(sender As Object, e As EventArgs) Handles btnPharmacist.Click
        Me.Hide()
        Pharmacist_Confirmation.Show()
    End Sub

    Private Sub btnAccountant_Click(sender As Object, e As EventArgs) Handles btnAccountant.Click
        Me.Hide()
        Accountant_Confirmation.Show()
    End Sub

    Private Sub btnManager_Click(sender As Object, e As EventArgs) Handles btnManager.Click
        Me.Hide()
        Manager_Confirmation.Show()
    End Sub
End Class